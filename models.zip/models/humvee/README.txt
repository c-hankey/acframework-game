8-25-98

================================================================

Model Name              : Humvee

installation directory  : quake2/baseq2/players/humvee

Author                  : Ben "Dysruptor" Howard

Email Address           : dysruptor@aol.com

Website Address         : http://www.geocities.com/TimesSquare/Arena/1769

Model description       : Humvee

Other info              : *********add what you want
Additional Credits to   : 
	* Q2modeler
        * Id Software
 

================================================================

* Play Information *

New Sounds              : NO

CTF Skins               : YES

VWEP Support            : No


* Construction *

Poly Count              : ************************

Vert Count              : *****************

Skin Count              : ********************

Base		        : *****************

Known Bugs              : It pops wheelies at odd times.


* Copyright / Permissions *
QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.
DO NOT feel free to edit my model as you see fit. This model is not to
 be distributed as part of any
commercial product.
