6/3/2000
================================================================
Model Name              : Speedy the snail
installation directory  : quake2/baseq2/players/speedy
Author                  : Flamingice
Skin Author             : Flamingice
Email Address           : Flamingice: Blee666@hotmail.com

Model description       : Speedy the Snail, a deathmatch snail with exhausts =)

Other info              : I made the model using Lightwave and did all the animations by hand using
                               the Q2Modeller, I really only did the model to try animating, as this is my
                               first model with me own animations =)



================================================================
* Play Information *

New Sounds              : Yes
CTF Skins               : Yes
VWEP Support            : Not at the moment: and prolly never, unless someone asks


* Construction *
Poly Count              : Tris 190;  Weapon 42
Vert Count              : Tris 103;   Weapon 32
Skin Count              : 4 including CTF
Base                    : New
Editor used             : Lightwave for modelling, Q2Modeller for animating, PaintShop Pro 6 and
                                Photoshop5 for skinning NST for skin linking

Known Bugs              : None

Build/Animation time    : 30 mins to model and mesh,     2 days to animate



* How to use this model *

Put the Speedy folder in your baseq2/players directory.  Make sure there are no stray files in 
your players directory otherwise you may not be able to select any custom models.

To play as Speedy, start Quake2, go to the multiplayer menu, choose player setup and select 
Speedy



* Copyright / Permissions *

QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.



 

