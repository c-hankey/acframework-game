

8/march/99

================================================================

Model Name              : Ostrich Man
installation directory  : quake2/baseq2/players/ostrich
Author                  : Lewis Mitchell

Email Address           : lewism@alphalink.com.au


Model description       : A man riding on the back of an ostrich.
                          

Other info              : Before any of you ask, Ostrich man is not meant to be a Chocobo.
                          The original inspiration for him came from my brother who wanted
                          me to make a model of a guy riding a horse. I told him I thought
                          it would be a little impractical, but a man riding the back of an
                          ostrich might be do-able. It was only afterwards I realised just
                          how chocobo-ish the whole idea was.
			  For those of you who are interested, the sound of the ostrich is
			  actually the sound of a Scarlet Macaw. I did manage to get my hands on a
			  tape of an ostrich but they sound so stupid I didn't think you would
			  mind a little bit of creative licence on my part. Besides, everyone
			  I asked didn't know what an ostrich sounded like anyway. 
  

Thanks to               : Npherno and Phillip Martin for their cool model editing programs
================================================================

* Play Information *



New Sounds              : Yes

CTF Skins               : Yes

VWEP Support            : Yes




* Construction *

Poly Count              : 815 (garrggg... Too many)
Vert Count              : 412

Skin Count              : 1

Base                    : New Model

Editor used             : Lightwave 3D, QME, Photoshop, Paintshop Pro, NST, WaveLab

Known Bugs              : Nah, none. I hope.
Build/Animation time    : About a month, on and off.




* How to use this model *

	Extract all the files in this zip file to a folder called 'ostrich' in the
baseq2/players directory of your quake2 folder.



* Copyright / Permissions *


Ostrich Man is (c) 1999 Lewis Mitchell. You can distribute Ostrich Man freely
as long as he is not used for any commercial venture or gain.
Oh and I don't mind if you want to use Ostrich Man as a base for another model,
just mention me in the readme file.

QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.


