2-22-99

================================================================

Model Name              : Decepticon1

installation directory  : quake2/baseq2/players/decepticon1

Author                  : Rikki "Phukyumoto(CW)" Knight

Skin Author             : Rikki "Phukyumoto(CW)" Knight
				AntiSpice
				Chiefymoto
				CWclan(3 skins)
				Evildead
				Grief
				Phukyumoto
			  Dan "Vindicator(CW)" Molzan
				Starscream
				Thundercracker
			  Steve "MassiveBitch(CW)" Irvine
				MassiveBitch

Email Address           : wigger@texas.net

Web Page                : http://www.planetquake.com/q2pmp/hostings/phunkyumoto

Clan Web Page	 	: Cybertronian Warriors
			  http://lonestar.texas.net/~wigger/cwclan

Model description       : A remake of the Starscream model. With new
                          stand, pain, flip, salute, taunt, and a death 
                          animations only. Also uses handheld weapons
                          now. And has a nifty 256x256 skin map.
                          This was mostly done for the guys in my 
                          clan who always refused to use anything but
                          the old starscream model, which I really 
                          didn't consider worthy of that honor. Hence
                          the reason most of the skins are personally
    			  for them.

Skin info              :  Clan member skins included are
                          AntiSpice(CW)
                          Chiefymoto(CW)
			  Evildead(CW)
                          Grief(CW)
                          Phukyumoto(CW)
			  MassiveBitch(CW) (done by himself)
                          and for all those that feel left out there are
                          3 generic CWclan skins included, although they
                          are very white and wash out quite a bit in GL
                          mode. Still haven't got the hang of that GL
                          thing... sorry.

			  Thankfully, Vindicator provided three public
			  use skins for you to enjoy.

                          (Update: Kray-zee just gave some very useful
                          info on this GL thing, the default intensity
                          setting is 2, if you change this to 1 your 
                          skins will be much clearer and wash out much
                          less. Do this in the console.
			  Type "set intensity 1", then you will have 
                          to type "vid_restart" afterwards. 
                          Thanks Kray-zee.)

                          I also left the Photoshop files in here so
                          you could see these things in thier truest
                          form of beauty. They kinda take up alot of
                          space so delete all the .psd files if you
                          don't want em.
               		
Animation info         :  This is my second attempt at animating in
                          Cstudio, nothing special... actually I'll
                          chock this up as a learning experience since
                          this one taught me quite a bit about how to
                          link the physique to the biped for these type
                          of models.

Thanks to               : My clan, the Cybertronian Warriors, the great-
                          est crew in all of webdom. All of the
			  [NEW] Nexus Elite Warriors. Rogue13 and the
                          Q2pmp, for giving me a new place to call home.
                          Brian "EvilBastard" Collins. Gwot. Mike
			  Cassidicus. Jason, Gears, Skeezer, and the
			  rest of the TFQ crew. Zilthai(get the skins
                          flowing), and sTuPiD fOoL for giving us a place
                          to frag all these years.
               

================================================================

* Play Information *

New Sounds              : YES (heinously stolen from Jason Seip's Sideswipe)

CTF Skins               : SORTA, You can just rename the colored CWclan
                          skins to the appropriate ctf skin name.

VWEP Support            : NOT FULLY YET(Will implement this when the vweap set
                          on my site is complete)


* Construction *

Poly Count              : 734 polys tris.md2/180 polys weapon.md2

Vert Count              : 525 Verts

Skin Count              : 12 Skins

Base                    : Starscream model

Editor used             : 3DSmax, Cstudio, Photoshop 4, NST, and Q2modeller

Known Bugs              : None unless you guys name the directory wrong,
			  then you'll see a red weapon.

Build/Animation time    : About 4 weeks of free time.


* How to use this model *

Put it in Quake2/baseq2/players/decepticon1, that's it.


* Copyright / Permissions *

QUAKE 2(R) is a registered trademark of id Software, Inc.

I specifically forbid modifying my model into garbage for distribution.
(It happens, anyone seen that Reflector model floating around? Made from
my Starscream.) Otherwise, skin, use, modify for personal benefit... 
whatever. Just don't distribute commercially or Hasbro will sue your ass.
Oh yeah :) This design and the characters that correspond with it are
owned by Hasbro Inc.



